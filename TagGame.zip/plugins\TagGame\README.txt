Tag Game Plugin Installation
===========================

Required Plugins:
1. DecentHolograms (for leaderboard display)
   Download from: https://www.spigotmc.org/resources/decentholograms-1-8-1-20-4.96927/
   Direct download: https://cdn.discordapp.com/attachments/1016321105013678080/1016321105244352522/DecentHolograms-2.8.3.jar

Installation Steps:
1. Download and install DecentHolograms first
2. Place the entire 'plugins' folder in your server's root directory
3. Start your server to generate default config files
4. Stop your server
5. Edit the config.yml file in plugins/TagGame/ to set your desired settings
6. Restart your server

Commands:
- /tag help - Shows help menu
- /tag - Opens the Tag Game menu
- /tag join - Join the Tag game
- /tag leave - Leave the Tag game
- /tag start - Start the Tag game (Admin only)
- /tag stop - Stop the Tag game (Admin only)
- /tag it - Check who is currently IT
- /tag score - View current scores
- /tag mode <mode> - Change game mode (Admin only)
- /tag setleaderboard - Create a holographic leaderboard (Admin only)

Permissions:
- tag.admin.start - Allows starting the game
- tag.admin.stop - Allows stopping the game
- tag.admin.mode - Allows changing game modes
- tag.admin.setleaderboard - Allows creating leaderboards

For support, please create an issue on the plugin's GitHub repository. 